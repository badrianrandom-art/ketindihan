import {Config} from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
Config.setConcurrency(2); // aman untuk Codespaces 2-core; naikkan kalau mesinmu lebih besar
