import React from 'react';
import {useCurrentFrame} from 'remotion';
import {lerp, wobble} from '../anim';
import {C} from '../theme';

export type CharacterProps = {
  /** 0 = berbaring, 1 = duduk tegak */
  lie?: number;
  /** 0 = mata terpejam, 1 = mata terbuka */
  eye?: number;
  /** 0..1 ekspresi takut (alis naik, mata melebar, mulut terbuka, keringat) */
  fear?: number;
  /** 0..1 ekspresi tenang (senyum tipis) */
  calm?: number;
  /** arah pandang pupil, -1..1 */
  lookX?: number;
  lookY?: number;
  /** 0..1 getaran tubuh saat mencoba bergerak */
  strain?: number;
  /** 0..1 gerak jari */
  twitch?: number;
  /** skala napas (otomatis dari frame jika tidak diisi) */
  breath?: number;
};

/** Bagian kepala: wajah minimalis, rambut konsisten. Koordinat lokal: pusat kepala di (0,0). */
const Head: React.FC<Required<Pick<CharacterProps, 'eye' | 'fear' | 'calm' | 'lookX' | 'lookY'>> & {t: number}> = ({
  eye,
  fear,
  calm,
  lookX,
  lookY,
  t,
}) => {
  const open = eye > 0.12;
  const eyeRy = Math.max(0.5, eye * (5 + fear * 3));
  const eyeRx = 4.6 + fear * 1.8;
  const ex = [-6, 15];
  const sweatY = ((t * 0.9) % 30) - 6;
  return (
    <g>
      {/* rambut belakang + sanggul */}
      <circle cx={-31} cy={12} r={15} fill={C.hair} />
      <ellipse cx={0} cy={0} rx={29} ry={34} fill={C.skin} />
      {/* rambut atas (poni menyamping) */}
      <path
        d="M-34 8 C-40 -30 -18 -48 8 -45 C30 -43 38 -22 31 -9 C20 -26 2 -24 -12 -14 C-22 -6 -22 10 -34 8 Z"
        fill={C.hair}
      />
      {/* telinga */}
      <ellipse cx={-24} cy={6} rx={4} ry={6} fill="#c89678" />
      {/* alis */}
      {open && (
        <g stroke={C.hair} strokeWidth={2.4} strokeLinecap="round" fill="none" opacity={0.85}>
          <path d={`M${ex[0] - 8} ${-13 - fear * 1} L${ex[0] + 6} ${-13 - fear * 6}`} />
          <path d={`M${ex[1] - 6} ${-13 - fear * 6} L${ex[1] + 8} ${-13 - fear * 1}`} />
        </g>
      )}
      {/* mata */}
      {ex.map((x, i) =>
        open ? (
          <g key={i}>
            <ellipse cx={x} cy={0} rx={eyeRx} ry={eyeRy} fill="#f3eee6" />
            <circle cx={x + lookX * 2.6} cy={lookY * 2 + 0.3} r={2.4 + fear * 0.4} fill="#1a1c2c" />
          </g>
        ) : (
          <path
            key={i}
            d={`M${x - 5} -1 Q${x} ${3 + calm} ${x + 5} -1`}
            stroke={C.hair}
            strokeWidth={2.2}
            strokeLinecap="round"
            fill="none"
          />
        ),
      )}
      {/* mulut */}
      {fear > 0.05 ? (
        <ellipse cx={5} cy={20} rx={3 + fear * 2.5} ry={1 + fear * 6} fill="#5a3838" opacity={Math.min(1, fear * 1.4)} />
      ) : (
        <path
          d={`M-2 20 Q5 ${20 + calm * 4} 12 20`}
          stroke="#8a5a52"
          strokeWidth={2}
          strokeLinecap="round"
          fill="none"
        />
      )}
      {/* keringat */}
      {fear > 0.4 && (
        <path
          d="M30 -6 q-4 7 0 10 q4 -3 0 -10 Z"
          fill="#9fc1ff"
          opacity={0.7 * fear}
          transform={`translate(0 ${sweatY})`}
        />
      )}
    </g>
  );
};

/** Karakter utama: bisa berbaring → duduk dengan satu rig (rotasi torso dari pinggul). */
export const Character: React.FC<CharacterProps> = ({
  lie = 0,
  eye = 0,
  fear = 0,
  calm = 0,
  lookX = 0.6,
  lookY = 0,
  strain = 0,
  twitch = 0,
  breath,
}) => {
  const frame = useCurrentFrame();
  const t = frame;
  const br = breath ?? Math.sin(frame / 14) * (1 - strain * 0.6);
  const px = lerp(372, 360, lie);
  const py = lerp(822, 862, lie);
  const rot = lerp(-84, 0, lie);
  const jx = wobble(t * 1.9, 1) * 2.2 * strain;
  const jy = wobble(t * 2.3, 2) * 1.6 * strain;
  // blanket
  const topY = lerp(806, 755, lie) - br * 2.2 * (1 - lie);
  const xL = lerp(246, 325, lie);
  const peakX = lerp(410, 420, lie);
  const blanket = `M${xL} 892 C${xL} ${topY + 34} ${xL + 22} ${topY} ${peakX} ${topY} C${peakX + 78} ${topY} 540 ${topY + 64} 540 892 Z`;
  const handX = lerp(300, 392, lie);
  const handY = lerp(topY + 4, 783, lie);
  const fingers = [-1, 0, 1].map((k) => twitch * (Math.sin(t * 0.9 + k * 1.7) * 16 + 10));
  return (
    <g>
      {/* torso + kepala */}
      <g transform={`translate(${px + jx} ${py + jy}) rotate(${rot})`}>
        <path d="M-40 0 L-52 -128 Q-54 -152 -28 -153 L28 -153 Q54 -152 52 -128 L40 0 Z" fill={C.greyShirt} />
        <rect x={-9} y={-172} width={18} height={26} rx={8} fill="#c89678" />
        <g transform={`translate(0 -200) rotate(${-rot * 0.88})`}>
          <Head eye={eye} fear={fear} calm={calm} lookX={lookX} lookY={lookY} t={t} />
        </g>
        {/* lengan */}
        <rect x={-16} y={-140} width={30} height={104} rx={15} fill="#8f93aa" transform="rotate(-12 0 -140)" />
      </g>
      {/* selimut menutupi pinggul-kaki */}
      <path d={blanket} fill={C.blanket} />
      <path
        d={`M${peakX + 24} ${topY + 10} C${peakX + 34} ${topY + 40} ${peakX + 30} ${topY + 70} ${peakX + 32} 888`}
        stroke="#3d3955"
        strokeWidth={5}
        strokeLinecap="round"
        fill="none"
        opacity={0.8}
      />
      {/* tangan di atas selimut */}
      <g transform={`translate(${handX + jx * 1.5} ${handY})`}>
        <ellipse cx={0} cy={0} rx={15} ry={9} fill={C.skin} />
        {fingers.map((a, i) => (
          <rect
            key={i}
            x={9}
            y={-6 + i * 5}
            width={13}
            height={4}
            rx={2}
            fill={C.skin}
            transform={`rotate(${a} 9 ${-4 + i * 5})`}
          />
        ))}
      </g>
    </g>
  );
};

/** Posisi kepala dalam koordinat desain untuk kamera/efek (perkiraan). */
export const headPos = (lie: number) => {
  const px = lerp(372, 360, lie);
  const py = lerp(822, 862, lie);
  const rot = (lerp(-84, 0, lie) * Math.PI) / 180;
  const ly = -200;
  return {x: px - ly * Math.sin(rot), y: py + ly * Math.cos(rot)};
};
