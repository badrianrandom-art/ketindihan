import React from 'react';
import {useCurrentFrame} from 'remotion';
import {wobble} from '../anim';
import {C} from '../theme';

/** Otak datar (sisi samping). Ukuran lokal ±300x240, pusat ±(150,120). */
export const Brain: React.FC<{
  x: number;
  y: number;
  scale?: number;
  /** 0..1 aktivitas korteks (glow beige) */
  cortex?: number;
  /** 0..1 batang otak (pons) menyala */
  stem?: number;
  /** 0..1 amigdala berdenyut */
  amygdala?: number;
  opacity?: number;
  tone?: 'purple' | 'grey';
}> = ({x, y, scale = 1, cortex = 0, stem = 0, amygdala = 0, opacity = 1, tone = 'purple'}) => {
  const f = useCurrentFrame();
  const float = Math.sin(f / 28) * 4;
  const base = tone === 'purple' ? '#6a6489' : '#6d7184';
  const shade = tone === 'purple' ? '#4b4568' : '#4d5163';
  const pulse = 1 + 0.18 * Math.sin(f / 4) * amygdala;
  const outline =
    'M40 130 C20 100 30 60 70 45 C90 15 140 5 175 22 C215 8 265 35 262 80 C285 100 280 140 250 155 C240 185 205 195 180 180 C165 195 135 200 120 182 C90 195 55 175 60 150 C50 148 44 140 40 130 Z';
  return (
    <g transform={`translate(${x - 150 * scale} ${y - 120 * scale + float}) scale(${scale})`} opacity={opacity}>
      <defs>
        <clipPath id="brainClip">
          <path d={outline} />
        </clipPath>
        <radialGradient id="cortexG" cx="0.5" cy="0.4" r="0.6">
          <stop offset="0" stopColor={C.beigeSoft} stopOpacity={0.85 * cortex} />
          <stop offset="1" stopColor={C.beige} stopOpacity={0.15 * cortex} />
        </radialGradient>
      </defs>
      {/* batang otak & serebelum */}
      <path d="M150 178 L168 178 L172 240 Q160 248 148 240 Z" fill={shade} />
      <rect x={146} y={196} width={30} height={14} rx={7} fill={C.beige} opacity={0.15 + 0.85 * stem} />
      <ellipse cx={212} cy={186} rx={44} ry={26} fill={shade} />
      <path d="M180 182 Q212 196 246 182 M184 192 Q212 206 242 192" stroke="#3b3754" strokeWidth={3} fill="none" opacity={0.7} />
      {/* korteks */}
      <path d={outline} fill={base} />
      <g clipPath="url(#brainClip)">
        <rect x={0} y={0} width={300} height={240} fill="url(#cortexG)" />
        {/* lipatan/sulci */}
        <g stroke={shade} strokeWidth={5} strokeLinecap="round" fill="none" opacity={0.75}>
          <path d="M80 70 Q110 60 130 85 Q150 105 125 125" />
          <path d="M150 40 Q175 60 165 90 Q160 115 190 120" />
          <path d="M205 40 Q230 55 225 85 Q222 110 250 118" />
          <path d="M70 120 Q95 110 100 140 Q105 165 80 165" />
          <path d="M140 140 Q165 150 160 175" />
          <path d="M200 135 Q225 140 240 160" />
        </g>
      </g>
      {/* amigdala */}
      <circle cx={128} cy={140} r={11 * pulse} fill={C.beige} opacity={0.25 + 0.75 * amygdala} />
      <circle cx={128} cy={140} r={20 * pulse} fill={C.beige} opacity={0.18 * amygdala} />
    </g>
  );
};

/** Siluet tubuh berbaring (tampak samping) dengan node otot yang bisa "terkunci". */
export const BodyLying: React.FC<{
  x: number;
  y: number;
  scale?: number;
  /** 0 = otot aktif (beige), 1 = otot terkunci (abu) */
  locked?: number;
  /** getaran kecil (mencoba bergerak) */
  strain?: number;
  opacity?: number;
}> = ({x, y, scale = 1, locked = 0, strain = 0, opacity = 1}) => {
  const f = useCurrentFrame();
  const nodes = [
    [70, 0], [120, -6], [170, -4], [220, 0], [270, 2], [330, 4], [390, 6], [450, 8],
    [505, 6], [150, 18], [250, 20], [350, 22], [440, 20],
  ];
  const jx = wobble(f * 2, 3) * 2 * strain;
  return (
    <g transform={`translate(${x + jx} ${y}) scale(${scale})`} opacity={opacity}>
      <g fill="#4b4568">
        <circle cx={0} cy={-6} r={38} />
        <rect x={32} y={-30} width={190} height={58} rx={28} />
        <rect x={190} y={-26} width={330} height={52} rx={26} />
        <rect x={480} y={-14} width={80} height={34} rx={17} />
      </g>
      <path d="M-30 -14 C-36 -52 -14 -62 8 -58 C26 -54 34 -34 28 -22 C18 -38 0 -36 -10 -26 Z" fill={C.hair} />
      {nodes.map(([nx, ny], i) => {
        const delay = i * 0.045;
        const k = Math.min(1, Math.max(0, (locked - delay) / 0.4));
        const col = k > 0.5 ? '#7d8196' : C.beige;
        const glow = (1 - k) * (0.6 + 0.4 * Math.sin(f / 6 + i));
        return (
          <g key={i}>
            <circle cx={nx} cy={ny} r={13} fill={C.beige} opacity={0.22 * glow} />
            <circle cx={nx} cy={ny} r={6.5} fill={col} opacity={k > 0.5 ? 0.7 : 0.95} />
          </g>
        );
      })}
    </g>
  );
};

/** Sosok bayangan di pintu (halusinasi): datar, tanpa wajah, outline ungu redup. */
export const ShadowFigure: React.FC<{x: number; y: number; scale?: number; opacity?: number; sway?: number}> = ({
  x,
  y,
  scale = 1,
  opacity = 1,
  sway = 0,
}) => {
  const f = useCurrentFrame();
  const s = Math.sin(f / 22) * sway;
  return (
    <g transform={`translate(${x + s * 3} ${y}) scale(${scale})`} opacity={opacity}>
      <defs>
        <radialGradient id="shHalo">
          <stop offset="0" stopColor="#8a5aa0" stopOpacity={0.35} />
          <stop offset="1" stopColor="#8a5aa0" stopOpacity={0} />
        </radialGradient>
      </defs>
      <ellipse cx={0} cy={-210} rx={150} ry={260} fill="url(#shHalo)" />
      <path
        d="M-34 0 L-40 -250 Q-70 -270 -74 -320 Q-64 -352 -40 -352 L-30 -372 Q0 -396 30 -372 L40 -352 Q64 -352 74 -320 Q70 -270 40 -250 L34 0 Z"
        fill="#090a13"
        stroke="#3a2f52"
        strokeWidth={3}
      />
      <ellipse cx={0} cy={-398} rx={30} ry={36} fill="#090a13" stroke="#3a2f52" strokeWidth={3} />
    </g>
  );
};

/** Tekanan di dada: tiga panah turun + bayangan berat. */
export const ChestPressure: React.FC<{x: number; y: number; amount: number}> = ({x, y, amount}) => {
  const f = useCurrentFrame();
  return (
    <g opacity={amount}>
      <ellipse cx={x} cy={y + 20} rx={92} ry={24} fill="#05060d" opacity={0.45} />
      {[-52, 0, 52].map((dx, i) => {
        const dy = ((f * 1.2 + i * 12) % 36) - 18;
        return (
          <path
            key={i}
            d={`M${x + dx - 12} ${y - 70 + dy} L${x + dx} ${y - 52 + dy} L${x + dx + 12} ${y - 70 + dy}`}
            stroke={C.beige}
            strokeWidth={4}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            opacity={0.8}
          />
        );
      })}
    </g>
  );
};
