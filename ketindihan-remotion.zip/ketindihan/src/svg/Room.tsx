import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Layer} from '../Camera';
import {wobble} from '../anim';
import {C, H, W} from '../theme';

type RoomProps = {
  /** 0..1 — seberapa takut/gelap (menggeser warna ke ungu redup & mematikan lampu) */
  fear?: number;
  /** 0..1 — kekuatan lampu meja */
  lamp?: number;
  /** 0..1 — pintu terbuka (panel menyempit, celah gelap terlihat) */
  doorOpen?: number;
  /** 0..1 — bulan lebih terang */
  moon?: number;
  children?: React.ReactNode; // digambar di layer tengah (sebelum selimut), misal karakter
};

const FLOOR_Y = 992;

/** Layer jauh: dinding, jendela, kalender, pintu, jaket. depth 0.7 */
export const RoomFar: React.FC<RoomProps> = ({fear = 0, lamp = 1, doorOpen = 0, moon = 1}) => {
  const f = useCurrentFrame();
  const pulse = 0.5 + 0.5 * Math.sin(f / 36);
  const panelScale = 1 - doorOpen * 0.55;
  return (
    <Layer depth={0.7}>
      <defs>
        <linearGradient id="wallG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#12172a" />
          <stop offset="1" stopColor="#181c2e" />
        </linearGradient>
        <radialGradient id="moonG">
          <stop offset="0" stopColor="#bfc8ff" stopOpacity={0.28 * moon} />
          <stop offset="1" stopColor="#bfc8ff" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="lampG">
          <stop offset="0" stopColor={C.beige} stopOpacity={0.3 * lamp} />
          <stop offset="1" stopColor={C.beige} stopOpacity="0" />
        </radialGradient>
        <linearGradient id="winG" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#2a3a68" />
          <stop offset="1" stopColor="#1d2850" />
        </linearGradient>
      </defs>
      {/* dinding & lantai (melebar agar kamera bebas pan/zoom) */}
      <rect x={-500} y={-500} width={W + 1000} height={FLOOR_Y + 500} fill="url(#wallG)" />
      <rect x={-500} y={FLOOR_Y} width={W + 1000} height={H} fill="#111522" />
      {/* jendela + bulan */}
      <circle cx={225} cy={400} r={230} fill="url(#moonG)" />
      <rect x={120} y={290} width={210} height={210} rx={6} fill="url(#winG)" stroke="#2f3b66" strokeWidth={5} />
      <rect x={222} y={290} width={6} height={210} fill="#2f3b66" />
      <circle cx={260} cy={358} r={24} fill="#e8e2cf" opacity={0.92} />
      <circle cx={268} cy={352} r={20} fill="#efe9d6" opacity={0.4} />
      {/* kalender */}
      <rect x={405} y={390} width={75} height={92} rx={3} fill="#a7a6b4" opacity={0.85} />
      <rect x={405} y={390} width={75} height={16} rx={3} fill="#9b6a5a" />
      {/* pintu */}
      <rect x={545} y={450} width={260} height={FLOOR_Y - 450} fill={C.doorDark} />
      <rect x={560} y={462} width={170} height={FLOOR_Y - 462} fill="#07080f" opacity={doorOpen} />
      <g transform={`translate(730 0) scale(${panelScale} 1) translate(-730 0)`}>
        <rect x={560} y={462} width={170} height={FLOOR_Y - 462} fill={C.door} />
        <rect x={582} y={492} width={112} height={200} rx={3} fill="#241f2f" />
        <rect x={582} y={726} width={112} height={222} rx={3} fill="#241f2f" />
        <circle cx={578} cy={740} r={6} fill="#bfae96" />
      </g>
      {/* jaket menggantung */}
      <line x1={498} y1={556} x2={498} y2={575} stroke="#2b2d44" strokeWidth={3} />
      <path d="M458 600 L498 578 L540 600 L540 740 L458 740 Z" fill="#3a4160" opacity={0.85} />
      {/* kilau lampu di dinding (denyut halus) */}
      <circle cx={30} cy={740} r={300 + pulse * 6} fill="url(#lampG)" />
      {/* tint ketakutan */}
      <rect x={-500} y={-500} width={W + 1000} height={FLOOR_Y + 500} fill={C.fear} opacity={0.38 * fear} />
    </Layer>
  );
};

/** Layer tengah: ranjang, nakas, lampu. depth 1 (sama dengan karakter) */
export const RoomMid: React.FC<RoomProps> = ({lamp = 1, fear = 0, children}) => (
  <Layer depth={1}>
    {/* nakas + lampu */}
    <rect x={-20} y={810} width={78} height={FLOOR_Y - 810} fill="#4a3b45" />
    <rect x={18} y={756} width={10} height={56} fill="#2a2430" />
    <path d="M-10 714 L52 714 L44 758 L-2 758 Z" fill={C.beige} opacity={0.35 + 0.65 * lamp * (1 - 0.7 * fear)} />
    {/* ranjang */}
    <rect x={65} y={888} width={480} height={FLOOR_Y - 888} rx={10} fill="#34365a" />
    <rect x={75} y={860} width={460} height={42} rx={14} fill="#4a4666" />
    <rect x={85} y={826} width={122} height={42} rx={21} fill="#8d87a8" />
    {children}
  </Layer>
);

/** Layer dekat: debu/partikel. depth 1.35 */
export const RoomNear: React.FC<{fear?: number}> = ({fear = 0}) => {
  const f = useCurrentFrame();
  const dots = Array.from({length: 16}, (_, i) => {
    const bx = ((i * 97) % 700) + 10;
    const by = 380 + ((i * 53) % 560);
    return {
      x: bx + Math.sin(f / (60 + i * 3) + i) * 14,
      y: by - ((f * (0.12 + (i % 4) * 0.05)) % 80) + wobble(f / 20, i) * 3,
      r: 1 + (i % 3) * 0.7,
      o: 0.18 + (i % 5) * 0.07,
    };
  });
  return (
    <Layer depth={1.35}>
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r={d.r} fill={fear > 0.3 ? '#c9a6d6' : '#cfd6ff'} opacity={d.o} />
      ))}
    </Layer>
  );
};

/** Vignette tetap (tidak ikut kamera). */
export const Vignette: React.FC<{strength?: number}> = ({strength = 0.55}) => (
  <g>
    <defs>
      <radialGradient id="vigG" cx="0.5" cy="0.5" r="0.75">
        <stop offset="0.45" stopColor="#05060d" stopOpacity="0" />
        <stop offset="1" stopColor="#05060d" stopOpacity={strength} />
      </radialGradient>
    </defs>
    <rect x={0} y={0} width={W} height={H} fill="url(#vigG)" />
  </g>
);
