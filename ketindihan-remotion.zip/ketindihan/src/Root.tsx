import React from 'react';
import {Audio, Composition, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Atonia} from './scenes/Atonia';
import {BrainScene} from './scenes/BrainScene';
import {Closing} from './scenes/Closing';
import {Fear} from './scenes/Fear';
import {Hook} from './scenes/Hook';
import {Release} from './scenes/Release';
import {Rem} from './scenes/Rem';
import {Stuck} from './scenes/Stuck';
import {Trigger} from './scenes/Trigger';
import {ease} from './anim';
import {loadFonts} from './fonts';
import {OVERLAP, SCENES, SceneKey, TOTAL_FRAMES, sec} from './timing';
import {FPS, OUT_H, OUT_W} from './theme';

loadFonts();

/** Crossfade halus di tepi scene (kecuali scene yang punya transisi sendiri). */
const Fade: React.FC<{dur: number; fadeIn?: boolean; children: React.ReactNode}> = ({dur, fadeIn = true, children}) => {
  const f = useCurrentFrame();
  const a = fadeIn ? ease(f, 0, OVERLAP, 0, 1) : 1;
  const b = ease(f, dur - OVERLAP, dur, 1, 0);
  return <div style={{position: 'absolute', inset: 0, opacity: Math.min(a, b)}}>{children}</div>;
};

type Item = {key: SceneKey; tail: number; fadeIn?: boolean; render: (dur: number) => React.ReactNode};

const ITEMS: Item[] = [
  {key: 'hook', tail: OVERLAP, render: () => <Hook />},
  {key: 'stuck', tail: OVERLAP, render: () => <Stuck />},
  {key: 'fear', tail: 40, render: () => <Fear />}, // scene berikutnya masuk dengan wipe lingkaran
  {key: 'brain', tail: OVERLAP, fadeIn: false, render: () => <BrainScene />},
  {key: 'rem', tail: OVERLAP, render: () => <Rem />},
  {key: 'atonia', tail: OVERLAP, render: () => <Atonia />},
  {key: 'trigger', tail: OVERLAP, render: () => <Trigger />},
  {key: 'release', tail: OVERLAP, render: () => <Release />},
  {key: 'closing', tail: 0, render: (d) => <Closing dur={d} />},
];

const Video: React.FC = () => (
  <div style={{position: 'absolute', inset: 0, background: '#0f1320'}}>
    <Audio src={staticFile('audio/narasi.mp3')} />
    {ITEMS.map((it) => {
      const s = SCENES[it.key];
      const from = sec(s.from);
      const dur = sec(s.to) - from + it.tail;
      return (
        <Sequence key={it.key} from={from} durationInFrames={dur} name={it.key}>
          <Fade dur={dur} fadeIn={it.fadeIn ?? true}>
            {it.render(dur)}
          </Fade>
        </Sequence>
      );
    })}
  </div>
);

export const Root: React.FC = () => (
  <Composition
    id="Ketindihan"
    component={Video}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={OUT_W}
    height={OUT_H}
  />
);
