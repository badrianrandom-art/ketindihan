import {FPS} from './theme';

// Batas scene diambil dari jeda napas di narasi.mp3 (deteksi senyap ffmpeg).
// Kalau narasimu beda/di-edit, cukup ubah angka detik di bawah ini.
export const sec = (s: number) => Math.round(s * FPS);

export const AUDIO_SECONDS = 65.23;
export const TOTAL_FRAMES = sec(AUDIO_SECONDS) + 6;

export const SCENES = {
  hook: {from: 0, to: 4.16},
  stuck: {from: 4.16, to: 9.24},
  fear: {from: 9.24, to: 18.1},
  brain: {from: 18.1, to: 26.5},
  rem: {from: 26.5, to: 36.98},
  atonia: {from: 36.98, to: 47.3},
  trigger: {from: 47.3, to: 56.78},
  release: {from: 56.78, to: 60.35},
  closing: {from: 60.35, to: AUDIO_SECONDS + 0.2},
} as const;

export type SceneKey = keyof typeof SCENES;
export const OVERLAP = 10; // frame crossfade antar scene
