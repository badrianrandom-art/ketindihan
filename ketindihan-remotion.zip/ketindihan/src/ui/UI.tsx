import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {ease, pop} from '../anim';
import {C, FONT_SANS, FONT_SERIF, HANDLE} from '../theme';

/** Wadah overlay HTML dalam koordinat desain 720x1280. */
export const Overlay: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{position: 'absolute', left: 0, top: 0, width: 720, height: 1280, pointerEvents: 'none'}}>{children}</div>
);

export const Watermark: React.FC = () => (
  <div
    style={{
      position: 'absolute',
      left: 40,
      top: 168,
      fontFamily: FONT_SANS,
      fontSize: 20,
      fontWeight: 500,
      color: 'rgba(255,255,255,0.5)',
    }}
  >
    {HANDLE}
  </div>
);

/** Label kecil huruf kapital berspasi lebar (seperti "SALDO"/"KAKAK"). */
export const Kicker: React.FC<{
  text: string;
  x: number;
  y: number;
  w?: number;
  align?: 'left' | 'center' | 'right';
  delay?: number;
  color?: string;
  size?: number;
}> = ({text, x, y, w = 640, align = 'left', delay = 0, color = C.beige, size = 20}) => {
  const f = useCurrentFrame();
  const p = ease(f, delay, delay + 14);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        textAlign: align,
        fontFamily: FONT_SANS,
        fontWeight: 500,
        fontSize: size,
        letterSpacing: size * 0.32,
        color,
        opacity: p,
        transform: `translateY(${(1 - p) * 10}px)`,
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </div>
  );
};

/** Teks besar yang muncul kata-per-kata (blur + naik), bisa keluar halus. */
export const RevealText: React.FC<{
  text: string;
  x: number;
  y: number;
  w?: number;
  size?: number;
  font?: 'sans' | 'serif';
  weight?: number;
  italic?: boolean;
  color?: string;
  align?: 'left' | 'center' | 'right';
  delay?: number;
  stagger?: number;
  lineHeight?: number;
  exitAt?: number;
}> = ({
  text,
  x,
  y,
  w = 640,
  size = 72,
  font = 'sans',
  weight = 600,
  italic = false,
  color = C.cream,
  align = 'left',
  delay = 0,
  stagger = 5,
  lineHeight = 1.08,
  exitAt,
}) => {
  const f = useCurrentFrame();
  const words = text.split(' ').flatMap((w) => (w.includes('\\n') ? w.split(/(\\n)/).filter(Boolean) : [w]));
  const out = exitAt === undefined ? 1 : ease(f, exitAt, exitAt + 10, 1, 0);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        textAlign: align,
        fontFamily: font === 'serif' ? FONT_SERIF : FONT_SANS,
        fontWeight: weight,
        fontStyle: italic ? 'italic' : 'normal',
        fontSize: size,
        lineHeight,
        color,
        letterSpacing: font === 'sans' ? -size * 0.015 : 0,
        opacity: out,
      }}
    >
      {words.map((wd, i) => {
        if (wd === '\\n') return <br key={i} />;
        const p = ease(f, delay + i * stagger, delay + i * stagger + 16);
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              marginRight: '0.26em',
              opacity: p,
              transform: `translateY(${(1 - p) * 22}px)`,
              filter: `blur(${(1 - p) * 8}px)`,
            }}
          >
            {wd}
          </span>
        );
      })}
    </div>
  );
};

/** Gelembung chat gaya referensi (biru tua, sudut membulat), muncul dengan spring. */
export const ChatBubble: React.FC<{
  text: string;
  x: number;
  y: number;
  delay?: number;
  maxWidth?: number;
  tone?: 'blue' | 'dark';
  caret?: boolean;
  exitAt?: number;
  size?: number;
}> = ({text, x, y, delay = 0, maxWidth = 300, tone = 'blue', caret = false, exitAt, size = 22}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = pop(f, fps, delay, 13, 140);
  const out = exitAt === undefined ? 1 : ease(f, exitAt, exitAt + 10, 1, 0);
  const shown = caret ? text.slice(0, Math.max(0, Math.floor((f - delay - 4) / 1.6))) : text;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        maxWidth,
        padding: '12px 20px',
        borderRadius: 18,
        background: tone === 'blue' ? C.chat : C.chatDark,
        color: C.cream,
        fontFamily: FONT_SANS,
        fontWeight: 500,
        fontSize: size,
        lineHeight: 1.25,
        opacity: Math.min(1, p * 1.4) * out,
        transform: `scale(${0.8 + 0.2 * p}) translateY(${(1 - p) * 14}px)`,
        transformOrigin: '0 100%',
        boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
      }}
    >
      {shown}
      {caret && f % 16 < 9 && <span style={{opacity: 0.8}}>|</span>}
    </div>
  );
};

/** Kartu notifikasi ala "M-BANKING": ikon bulat + label kecil + judul + nilai. */
export const InfoCard: React.FC<{
  label: string;
  title: string;
  value?: string;
  x: number;
  y: number;
  w?: number;
  delay?: number;
  icon?: string;
  exitAt?: number;
}> = ({label, title, value, x, y, w = 420, delay = 0, icon = '●', exitAt}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = pop(f, fps, delay, 15, 120);
  const out = exitAt === undefined ? 1 : ease(f, exitAt, exitAt + 10, 1, 0);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        display: 'flex',
        alignItems: 'center',
        gap: 18,
        padding: '16px 22px',
        borderRadius: 22,
        background: C.card,
        border: '1px solid rgba(255,255,255,0.07)',
        boxShadow: '0 14px 36px rgba(0,0,0,0.35)',
        opacity: Math.min(1, p * 1.5) * out,
        transform: `translateY(${(1 - p) * 30}px) scale(${0.94 + 0.06 * p})`,
        fontFamily: FONT_SANS,
      }}
    >
      <div
        style={{
          width: 44,
          height: 44,
          borderRadius: 22,
          background: 'rgba(216,185,138,0.16)',
          color: C.beige,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 20,
          flexShrink: 0,
        }}
      >
        {icon}
      </div>
      <div style={{flex: 1}}>
        <div style={{fontSize: 13, letterSpacing: 3.6, color: C.beige, fontWeight: 500}}>{label}</div>
        <div style={{fontSize: 22, color: C.cream, fontWeight: 500, marginTop: 3}}>{title}</div>
        {value && <div style={{fontSize: 30, color: C.white, fontWeight: 600, marginTop: 2}}>{value}</div>}
      </div>
    </div>
  );
};

/** Penampil jam digital kecil (elemen UI). */
export const ClockChip: React.FC<{text: string; x: number; y: number; delay?: number}> = ({text, x, y, delay = 0}) => {
  const f = useCurrentFrame();
  const p = ease(f, delay, delay + 14);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        fontFamily: FONT_SANS,
        fontWeight: 600,
        fontSize: 26,
        letterSpacing: 2,
        color: C.beige,
        padding: '8px 18px',
        borderRadius: 14,
        background: 'rgba(15,19,32,0.7)',
        border: '1px solid rgba(216,185,138,0.25)',
        opacity: p,
        transform: `translateY(${(1 - p) * 8}px)`,
      }}
    >
      {text}
    </div>
  );
};
