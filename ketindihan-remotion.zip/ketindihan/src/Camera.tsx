import React, {createContext, useContext} from 'react';
import {H, W} from './theme';

export type Cam = {x: number; y: number; zoom: number};
const CamCtx = createContext<Cam>({x: W / 2, y: H / 2, zoom: 1});
export const useCam = () => useContext(CamCtx);

/** Kamera 2D: (x,y) = titik desain yang ingin berada di tengah layar. */
export const CameraRig: React.FC<{x?: number; y?: number; zoom?: number; children: React.ReactNode}> = ({
  x = W / 2,
  y = H / 2,
  zoom = 1,
  children,
}) => <CamCtx.Provider value={{x, y, zoom}}>{children}</CamCtx.Provider>;

/** Layer parallax. depth 0 = diam (UI/overlay), 1 = bergerak penuh mengikuti kamera. */
export const Layer: React.FC<{depth?: number; children: React.ReactNode}> = ({depth = 1, children}) => {
  const {x, y, zoom} = useCam();
  const z = 1 + (zoom - 1) * depth;
  const fx = W / 2 + (x - W / 2) * depth;
  const fy = H / 2 + (y - H / 2) * depth;
  return <g transform={`translate(${W / 2} ${H / 2}) scale(${z}) translate(${-fx} ${-fy})`}>{children}</g>;
};
