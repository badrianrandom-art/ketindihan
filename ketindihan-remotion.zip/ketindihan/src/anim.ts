import {Easing, interpolate, spring} from 'remotion';

export const OUT = Easing.bezier(0.22, 1, 0.36, 1); // easeOutExpo-ish, halus seperti referensi
export const INOUT = Easing.bezier(0.65, 0, 0.35, 1);

/** progress ter-clamp dari frame a..b menjadi from..to */
export const ease = (
  f: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (t: number) => number = OUT,
) =>
  interpolate(f, [a, b], [from, to], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** noise deterministik sederhana (tanpa Math.random agar render konsisten) */
export const wobble = (t: number, seed = 0) =>
  Math.sin(t * 1.7 + seed * 12.9898) * 0.6 + Math.sin(t * 3.1 + seed * 78.233) * 0.4;

export const pop = (frame: number, fps: number, delay = 0, damping = 14, stiffness = 120) =>
  spring({frame: frame - delay, fps, config: {damping, stiffness, mass: 0.8}});

/** nilai 0..1 untuk fade-in lalu fade-out dalam rentang [a,b] */
export const window01 = (f: number, a: number, b: number, fade = 10) =>
  Math.min(ease(f, a, a + fade, 0, 1), ease(f, b - fade, b, 1, 0));
