import React from 'react';
import {AbsoluteFill} from 'remotion';
import {C, H, OUT_H, OUT_W, W} from './theme';

/** Kanvas desain 720x1280 yang di-scale ke 1080x1920. Children = SVG (viewBox desain) + overlay HTML. */
export const Stage: React.FC<{children: React.ReactNode; bg?: string}> = ({children, bg = C.bgDeep}) => (
  <AbsoluteFill style={{background: bg, overflow: 'hidden'}}>
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: W,
        height: H,
        transform: `scale(${OUT_W / W})`,
        transformOrigin: '0 0',
      }}
    >
      {children}
    </div>
  </AbsoluteFill>
);

export const SceneSvg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg
    width={W}
    height={H}
    viewBox={`0 0 ${W} ${H}`}
    style={{position: 'absolute', left: 0, top: 0, overflow: 'hidden'}}
  >
    {children}
  </svg>
);

export const _ratio = OUT_H / H;
