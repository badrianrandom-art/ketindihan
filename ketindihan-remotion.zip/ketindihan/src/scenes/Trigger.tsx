import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CameraRig, Layer} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT} from '../anim';
import {Brain} from '../svg/Anatomy';
import {C} from '../theme';
import {InfoCard, Kicker, Overlay, RevealText, Watermark} from '../ui/UI';
import {Halo} from './BrainScene';

/** Scene 7 — Amigdala ikut aktif (rasa takut) + pemicu umum, gaya kartu notifikasi. */
export const Trigger: React.FC = () => {
  const f = useCurrentFrame();
  const amy = ease(f, 20, 60) * (0.6 + 0.4 * Math.sin(f / 5) ** 2);
  const zoom = 1 + 0.08 * ease(f, 0, 280, 0, 1, INOUT);
  return (
    <Stage bg="#171630">
      <SceneSvg>
        <CameraRig x={360} y={700} zoom={zoom}>
          <Layer depth={0.4}>
            <Halo cx={360} cy={700} color="#7a4f8a" speed={1.4} />
          </Layer>
          <Layer depth={1}>
            <Brain x={360} y={710} scale={1.0} cortex={0.3} stem={0.2} amygdala={amy} />
          </Layer>
        </CameraRig>
      </SceneSvg>
      <Overlay>
        <Watermark />
        <Kicker text="PERNAH MENGALAMINYA" x={40} y={236} delay={6} />
        <RevealText text="±8%" x={40} y={262} size={172} delay={12} />
        <RevealText
          text="orang pernah ketindihan setidaknya sekali seumur hidup."
          x={40}
          y={468}
          w={430}
          size={28}
          font="serif"
          weight={400}
          color={C.beigeSoft}
          delay={36}
        />
        <Kicker text="AMIGDALA = ALARM TAKUT" x={300} y={824} w={380} align="right" delay={64} size={14} color={C.cream} />
        <InfoCard label="PEMICU" title="Kurang tidur" icon="☾" x={40} y={920} w={640} delay={84} />
        <InfoCard label="PEMICU" title="Jadwal tidur berantakan" icon="◷" x={40} y={1020} w={640} delay={120} />
        <InfoCard label="PEMICU" title="Stres berlebih" icon="≋" x={40} y={1120} w={640} delay={156} />
      </Overlay>
    </Stage>
  );
};
