import React from 'react';
import {useCurrentFrame} from 'remotion';
import {SceneSvg, Stage} from '../Stage';
import {ease} from '../anim';
import {C, H, W} from '../theme';
import {Overlay, RevealText, Watermark} from '../ui/UI';
import {Halo} from './BrainScene';

/** Scene 9 — Closing: tipografi kuat di atas halo redup, serif + italic beige (seperti referensi). */
export const Closing: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const moon = ease(f, 6, 40);
  const out = ease(f, dur - 26, dur - 4, 1, 0);
  return (
    <Stage bg="#0d1120">
      <SceneSvg>
        <defs>
          <radialGradient id="closeG" cx="0.5" cy="0.45" r="0.7">
            <stop offset="0" stopColor="#2a2850" />
            <stop offset="1" stopColor="#0d1120" />
          </radialGradient>
        </defs>
        <rect x={0} y={0} width={W} height={H} fill="url(#closeG)" />
        <Halo cx={360} cy={560} color="#6a64a8" speed={0.6} />
        <g opacity={moon} transform={`translate(360 ${430 - (1 - moon) * 14})`}>
          <circle r={30} fill="#e8e2cf" opacity={0.95} />
          <circle cx={13} cy={-8} r={26} fill="#1b1f38" />
        </g>
      </SceneSvg>
      <Overlay>
        <div style={{opacity: out}}>
          <Watermark />
          <RevealText text="Tubuhmu aman," x={60} y={520} w={600} align="center" size={84} font="serif" weight={400} delay={20} />
          <RevealText
            text="otakmu hanya bangun lebih dulu."
            x={80}
            y={716}
            w={560}
            align="center"
            size={58}
            font="serif"
            italic
            weight={400}
            color={C.beige}
            delay={52}
          />
        </div>
      </Overlay>
    </Stage>
  );
};
