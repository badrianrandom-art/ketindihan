import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CameraRig} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT} from '../anim';
import {Character} from '../svg/Character';
import {RoomFar, RoomMid, RoomNear, Vignette} from '../svg/Room';
import {Kicker, Overlay, RevealText, Watermark} from '../ui/UI';
import {C} from '../theme';

/** Scene 1 — Hook: orang tidur di kamar, kamera mendorong pelan ke ranjang. */
export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const t = ease(f, 0, 130, 0, 1, INOUT);
  const cx = 360 - 30 * t;
  const cy = 640 + 120 * t;
  const zoom = 1 + 0.16 * t;
  return (
    <Stage>
      <SceneSvg>
        <CameraRig x={cx} y={cy} zoom={zoom}>
          <RoomFar lamp={0.9} />
          <RoomMid lamp={0.9}>
            <Character lie={0} eye={0} />
          </RoomMid>
          <RoomNear />
        </CameraRig>
        <Vignette strength={0.5} />
      </SceneSvg>
      <Overlay>
        <Watermark />
        <Kicker text="FENOMENA TIDUR" x={40} y={236} delay={6} />
        <RevealText text="Ketindihan" x={40} y={266} size={118} font="serif" weight={700} delay={12} color={C.cream} />
      </Overlay>
    </Stage>
  );
};
