import React from 'react';
import {useCurrentFrame, useVideoConfig, spring} from 'remotion';
import {CameraRig} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT} from '../anim';
import {Character} from '../svg/Character';
import {RoomFar, RoomMid, RoomNear, Vignette} from '../svg/Room';
import {C} from '../theme';
import {Overlay, RevealText, Watermark} from '../ui/UI';

/** Scene 8 — Jari bergerak, tubuh bangun, karakter kembali tenang, lampu menyala. */
export const Release: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fear = ease(f, 0, 40, 0.6, 0);
  const twitch = ease(f, 6, 24);
  const strain = ease(f, 0, 30, 0.8, 0.2);
  const sit = spring({frame: f - 44, fps, config: {damping: 16, stiffness: 70, mass: 1}});
  const calm = ease(f, 60, 95);
  const lamp = ease(f, 52, 80, 0.2, 1);
  const z = ease(f, 0, 90, 0, 1, INOUT);
  return (
    <Stage>
      <SceneSvg>
        <CameraRig x={290 + 70 * z} y={800 - 120 * z} zoom={1.6 - 0.55 * z}>
          <RoomFar lamp={lamp} fear={fear * 0.5} />
          <RoomMid lamp={lamp}>
            <Character
              lie={sit}
              eye={1}
              fear={fear}
              calm={calm}
              lookX={0.4}
              strain={strain * (1 - sit)}
              twitch={twitch * (1 - sit * 0.8)}
              breath={Math.sin(f / 10)}
            />
          </RoomMid>
          <RoomNear />
        </CameraRig>
        <Vignette strength={0.5} />
      </SceneSvg>
      <Overlay>
        <Watermark />
        <RevealText text="Jari pertama \n bergerak." x={40} y={1040} size={48} font="serif" italic weight={400} color={C.beigeSoft} delay={10} />
      </Overlay>
    </Stage>
  );
};
