import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CameraRig, Layer} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT} from '../anim';
import {BodyLying, Brain} from '../svg/Anatomy';
import {C, H, W} from '../theme';
import {ChatBubble, Kicker, Overlay, RevealText, Watermark} from '../ui/UI';
import {Halo} from './BrainScene';

/** Scene 6 — Atonia REM: otak sadar, sinyal ke otot terblokir, otot "terkunci". */
export const Atonia: React.FC = () => {
  const f = useCurrentFrame();
  const zoom = 1 + 0.06 * ease(f, 0, 300, 0, 1, INOUT);
  const locked = ease(f, 70, 190, 0, 1, INOUT);
  const strain = ease(f, 190, 230) * (0.5 + 0.5 * Math.sin(f / 4) ** 2);
  const gateX = 360;
  const gateY = 815;
  // titik sinyal turun dari batang otak; berhenti di gerbang lalu memantul
  const dots = [0, 1, 2, 3].map((i) => {
    const p = ((f * 0.011 + i / 4) % 1);
    const y = 690 + p * (gateY - 690 - 14);
    return {y, o: ease(f, 40, 60) * (1 - p * 0.3)};
  });
  const blocked = ease(f, 110, 130);
  return (
    <Stage bg="#12162a">
      <SceneSvg>
        <CameraRig x={360} y={720} zoom={zoom}>
          <Layer depth={0.3}>
            <Halo cx={360} cy={600} color="#5a5aa0" speed={0.8} />
          </Layer>
          <Layer depth={1}>
            <Brain x={360} y={600} scale={0.9} cortex={0.9} stem={0.6} />
            {/* jalur sinyal: otak -> otot */}
            <path d="M360 700 L360 990" stroke="#8a8fa3" strokeWidth={2} strokeDasharray="4 8" opacity={0.5} />
            {dots.map((d, i) => (
              <circle key={i} cx={360} cy={d.y} r={6} fill={C.beige} opacity={d.o} />
            ))}
            {/* gerbang "atonia" */}
            <g transform={`translate(${gateX} ${gateY})`} opacity={ease(f, 90, 112)}>
              <circle r={36} fill="#1c1a30" stroke={C.beige} strokeWidth={3} />
              <path d="M-12 -12 L12 12 M12 -12 L-12 12" stroke={C.beige} strokeWidth={5} strokeLinecap="round" opacity={blocked} />
              <rect x={-12} y={-4} width={24} height={20} rx={4} fill={C.beige} opacity={1 - blocked} />
              <path d="M-8 -4 V-12 a8 8 0 0 1 16 0 V-4" stroke={C.beige} strokeWidth={4} fill="none" opacity={1 - blocked} />
            </g>
            <BodyLying x={80} y={990} scale={0.88} locked={locked} strain={strain} />
          </Layer>
        </CameraRig>
      </SceneSvg>
      <Overlay>
        <Watermark />
        <Kicker text="ATONIA REM" x={40} y={236} delay={10} />
        <RevealText text="Otak bangun." x={40} y={266} size={74} delay={16} />
        <RevealText
          text="Otot masih tidur."
          x={40}
          y={346}
          size={64}
          font="serif"
          italic
          weight={400}
          color={C.beige}
          delay={60}
        />
        <Kicker text="SADAR" x={520} y={500} w={160} align="right" delay={30} size={15} color={C.cream} />
        <Kicker text="LUMPUH SEMENTARA" x={380} y={1036} w={300} align="right" delay={150} size={14} color={C.cream} />
        <ChatBubble text="Otak: ayo gerak!" x={40} y={1100} delay={120} maxWidth={300} />
        <ChatBubble text="Otot: …belum boleh." x={330} y={1166} delay={170} maxWidth={340} tone="dark" />
      </Overlay>
    </Stage>
  );
};
