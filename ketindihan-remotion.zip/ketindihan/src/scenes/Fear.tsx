import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CameraRig, Layer} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT, lerp} from '../anim';
import {ChestPressure, ShadowFigure} from '../svg/Anatomy';
import {Character} from '../svg/Character';
import {RoomFar, RoomMid, RoomNear, Vignette} from '../svg/Room';
import {C, H, W} from '../theme';
import {ChatBubble, Kicker, Overlay, RevealText, Watermark} from '../ui/UI';

const World: React.FC<{
  cam: {x: number; y: number; zoom: number};
  fear: number;
  door: number;
  figure: number;
  pressure: number;
  lookX: number;
}> = ({cam, fear, door, figure, pressure, lookX}) => {
  const f = useCurrentFrame();
  return (
    <CameraRig x={cam.x} y={cam.y} zoom={cam.zoom}>
      <RoomFar lamp={0.35 * (1 - fear)} fear={fear} doorOpen={door} moon={1 - 0.5 * fear} />
      <RoomMid lamp={0.35 * (1 - fear)} fear={fear}>
        <Character
          lie={0}
          eye={1}
          fear={fear}
          lookX={lookX}
          strain={0.7 + 0.3 * Math.sin(f / 4) ** 2}
          twitch={0.5}
        />
        <ChestPressure x={335} y={800} amount={pressure} />
      </RoomMid>
      <RoomNear fear={fear} />
      {/* sosok di pintu: sejajar layer pintu (depth 0.7) agar parallax konsisten */}
      <FigureLayer opacity={figure} />
    </CameraRig>
  );
};

const FigureLayer: React.FC<{opacity: number}> = ({opacity}) => (
  <Layer depth={0.85}>
    <ShadowFigure x={640} y={992} scale={0.92} opacity={opacity} sway={1} />
  </Layer>
);

/** Scene 3 — Ketakutan & halusinasi. Fase 1: pan ke pintu. Fase 2: split-screen (wajah | sosok). */
export const Fear: React.FC = () => {
  const f = useCurrentFrame();
  const fear = ease(f, 8, 70);
  const door = ease(f, 30, 75);
  const figure = ease(f, 50, 85);
  const pressure = ease(f, 150, 180);

  // kamera kiri: karakter -> pintu -> kembali ke karakter (saat split)
  const a = ease(f, 20, 100, 0, 1, INOUT);
  const b = ease(f, 118, 160, 0, 1, INOUT);
  const left = {
    x: lerp(lerp(330, 540, a), 190, b),
    y: lerp(lerp(700, 760, a), 790, b),
    zoom: lerp(lerp(1.05, 1.3, a), 1.9, b),
  };
  const right = {x: 610, y: 740, zoom: 1.45};

  const sp = ease(f, 118, 150, 0, 1, INOUT);
  const lw = lerp(W, 356, sp);
  const rx = lerp(W, 364, sp);
  return (
    <Stage>
      <SceneSvg>
        <defs>
          <clipPath id="fearL">
            <rect x={0} y={0} width={lw} height={H} />
          </clipPath>
          <clipPath id="fearR">
            <rect x={rx} y={0} width={W - rx} height={H} />
          </clipPath>
        </defs>
        <g clipPath="url(#fearL)">
          <g transform={`translate(${-180 * sp} 0)`}>
            <World cam={left} fear={fear} door={door} figure={figure} pressure={pressure} lookX={1} />
          </g>
        </g>
        <g clipPath="url(#fearR)">
          <g transform={`translate(${180 * sp} 0)`}>
            <World cam={right} fear={fear} door={door} figure={figure} pressure={0} lookX={1} />
          </g>
        </g>
        <rect x={356} y={0} width={8} height={H} fill="#07080f" opacity={sp} />
        <Vignette strength={0.55 + 0.25 * fear} />
      </SceneSvg>
      <Overlay>
        <Watermark />
        <RevealText
          text="Ada sosok \n di pintu."
          x={40}
          y={226}
          size={92}
          font="serif"
          weight={700}
          delay={40}
          exitAt={118}
          color={C.cream}
        />
        <Kicker text="HALUSINASI" x={40} y={238} delay={130} align="left" color={C.beige} />
        <RevealText text="Dada terasa \n berat." x={40} y={272} size={74} delay={138} />
        <ChatBubble text="Sesak." x={40} y={1030} delay={168} maxWidth={200} />
        <ChatBubble text="Seperti ada yang mengawasi…" x={40} y={1100} delay={196} maxWidth={360} tone="dark" />
        <ChatBubble text="Mau teriak, suara tak keluar." x={40} y={1170} delay={226} maxWidth={420} />
      </Overlay>
    </Stage>
  );
};
