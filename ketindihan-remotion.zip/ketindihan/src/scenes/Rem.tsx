import React from 'react';
import {useCurrentFrame} from 'remotion';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT, lerp, wobble} from '../anim';
import {BodyLying, Brain} from '../svg/Anatomy';
import {C, H, W} from '../theme';
import {Kicker, Overlay, RevealText, Watermark} from '../ui/UI';

// level: 0 terjaga, 1 REM, 2 N1, 3 N2, 4 N3
const HYPNO: [number, number][] = [
  [0, 0], [0.04, 2], [0.08, 3], [0.14, 4], [0.26, 3], [0.3, 1], [0.36, 1], [0.38, 3], [0.5, 4],
  [0.58, 3], [0.64, 1], [0.74, 1], [0.78, 3], [0.9, 2], [0.95, 1], [1, 0],
];
const HX = 70;
const HW = 590;
const HY = 1010;
const HH = 120;
const px = (t: number) => HX + t * HW;
const py = (l: number) => HY + (l / 4) * HH;

const Hypnogram: React.FC<{progress: number; fade: number}> = ({progress, fade}) => (
  <g opacity={fade}>
    <rect x={40} y={970} width={640} height={200} rx={22} fill={C.card} stroke="rgba(255,255,255,0.07)" />
    {HYPNO.slice(0, -1).map(([t0, l0], i) => {
      const [t1, l1] = HYPNO[i + 1];
      const rem = l0 === 1;
      const shown = Math.min(1, Math.max(0, (progress - t0) / Math.max(0.001, t1 - t0)));
      return (
        <g key={i} opacity={progress >= t0 ? 1 : 0}>
          <line
            x1={px(t0)}
            y1={py(l0)}
            x2={px(lerp(t0, t1, shown))}
            y2={py(l0)}
            stroke={rem ? C.beige : '#8a8fa3'}
            strokeWidth={rem ? 7 : 3}
            strokeLinecap="round"
          />
          {shown >= 1 && <line x1={px(t1)} y1={py(l0)} x2={px(t1)} y2={py(l1)} stroke="#8a8fa3" strokeWidth={3} />}
        </g>
      );
    })}
    <text x={52} y={py(1) + 5} fontFamily="Inter, sans-serif" fontSize={13} fill={C.beige} letterSpacing={2}>
      REM
    </text>
    <text x={52} y={py(4) + 5} fontFamily="Inter, sans-serif" fontSize={13} fill="#8a8fa3" letterSpacing={2}>
      DALAM
    </text>
  </g>
);

const EyeIcon: React.FC<{x: number; y: number; dir: number}> = ({x, y, dir}) => (
  <g transform={`translate(${x} ${y})`}>
    <path d="M-44 0 Q0 -34 44 0 Q0 34 -44 0 Z" fill="#e9e3d6" opacity={0.92} />
    <circle cx={dir * 18} cy={0} r={13} fill="#1a1c2c" />
    <circle cx={dir * 18 + 4} cy={-4} r={4} fill="#fff" opacity={0.8} />
  </g>
);

/** Scene 5 — Mekanisme tidur REM: split-screen OTAK | TUBUH + hipnogram. */
export const Rem: React.FC = () => {
  const f = useCurrentFrame();
  const slide = ease(f, 0, 30, 0, 1, INOUT);
  const eyeX = Math.sin(f / 4.5);
  const ew = ease(f, 20, 40);
  const wave = (x: number) => {
    const amp = 24 * ease(f, 20, 60);
    return 510 + wobble(x / 11 + f * 0.35, 4) * amp + Math.sin(x / 5 + f / 3) * amp * 0.35;
  };
  const wpath = Array.from({length: 36}, (_, i) => {
    const x = 28 + i * 9;
    return `${i === 0 ? 'M' : 'L'}${x} ${wave(x) + 330}`;
  }).join(' ');
  const progress = ease(f, 40, 290, 0, 1, (t) => t);
  return (
    <Stage bg={C.bgDeep}>
      <SceneSvg>
        <defs>
          <clipPath id="remL">
            <rect x={0} y={0} width={356} height={H} />
          </clipPath>
          <clipPath id="remR">
            <rect x={364} y={0} width={356} height={H} />
          </clipPath>
        </defs>
        <g clipPath="url(#remL)" transform={`translate(${(slide - 1) * 400} 0)`}>
          <rect x={0} y={0} width={356} height={H} fill="#151a30" />
          <circle cx={178} cy={640} r={200} fill="#5a5aa0" opacity={0.14} />
          <Brain x={178} y={630} scale={1.05} cortex={0.6 + 0.3 * Math.sin(f / 8)} stem={0.9} />
          <path d={wpath} transform="translate(0 -30)" stroke={C.beige} strokeWidth={4} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={ew} />
        </g>
        <g clipPath="url(#remR)" transform={`translate(${(1 - slide) * 400} 0)`}>
          <rect x={364} y={0} width={356} height={H} fill="#21192c" />
          <circle cx={540} cy={640} r={200} fill="#8a5f6a" opacity={0.1} />
          <EyeIcon x={542} y={470} dir={eyeX > 0 ? 1 : -1} />
          <BodyLying x={392} y={700} scale={0.57} locked={0} />
        </g>
        <Hypnogram progress={progress} fade={ease(f, 30, 50)} />
      </SceneSvg>
      <Overlay>
        <Watermark />
        <Kicker text="OTAK" x={0} y={212} w={356} align="center" delay={20} size={18} />
        <Kicker text="TUBUH" x={364} y={212} w={356} align="center" delay={20} size={18} />
        <RevealText text="REM" x={0} y={246} w={720} align="center" size={150} delay={14} />
        <RevealText
          text="mata bergerak cepat, otak bermimpi."
          x={90}
          y={880}
          w={540}
          align="center"
          size={30}
          font="serif"
          italic
          weight={400}
          color={C.beige}
          delay={60}
        />
      </Overlay>
    </Stage>
  );
};
