import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CameraRig} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT} from '../anim';
import {Character} from '../svg/Character';
import {RoomFar, RoomMid, RoomNear, Vignette} from '../svg/Room';
import {C} from '../theme';
import {ClockChip, Kicker, Overlay, RevealText, Watermark} from '../ui/UI';

/** Scene 2 — Terbangun tapi tubuh tak bisa bergerak: zoom ke wajah, mata terbuka, tangan bergetar. */
export const Stuck: React.FC = () => {
  const f = useCurrentFrame();
  const z = ease(f, 0, 60, 0, 1, INOUT);
  const eye = ease(f, 14, 26);
  const strain = ease(f, 60, 100) * (0.6 + 0.4 * Math.sin(f / 5) ** 2);
  const twitch = ease(f, 80, 100) * (f > 100 ? 1 : 0.6);
  return (
    <Stage>
      <SceneSvg>
        <CameraRig x={360 - 200 * z} y={640 + 160 * z} zoom={1.12 + 0.75 * z}>
          <RoomFar lamp={0.8} />
          <RoomMid lamp={0.8}>
            <Character lie={0} eye={eye} lookY={-0.7} lookX={0.1} strain={strain} twitch={twitch} calm={0} />
          </RoomMid>
          <RoomNear />
        </CameraRig>
        <Vignette strength={0.6} />
      </SceneSvg>
      <Overlay>
        <Watermark />
        <ClockChip text="03:12" x={520} y={200} delay={4} />
        <Kicker text="MATA TERBUKA" x={40} y={252} delay={18} />
        <RevealText text="Sadar." x={40} y={282} size={128} font="serif" italic weight={400} color={C.beigeSoft} delay={24} />
        <RevealText
          text="tapi tubuh \n tak mau bergerak."
          x={300}
          y={1030}
          w={380}
          align="right"
          size={40}
          font="serif"
          weight={400}
          delay={70}
        />
      </Overlay>
    </Stage>
  );
};
