import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CameraRig, Layer} from '../Camera';
import {SceneSvg, Stage} from '../Stage';
import {ease, INOUT} from '../anim';
import {Brain} from '../svg/Anatomy';
import {C, H, W} from '../theme';
import {Kicker, Overlay, RevealText, Watermark} from '../ui/UI';

/** Halo konsentris bergelombang (mengacu pada lingkaran cahaya di bagian ponsel referensi). */
export const Halo: React.FC<{cx: number; cy: number; color?: string; speed?: number}> = ({
  cx,
  cy,
  color = '#6a6aa0',
  speed = 1,
}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {[0, 1, 2].map((i) => {
        const p = ((f * speed) / 90 + i / 3) % 1;
        return <circle key={i} cx={cx} cy={cy} r={120 + p * 300} fill="none" stroke={color} strokeWidth={2} opacity={(1 - p) * 0.35} />;
      })}
      <ellipse cx={cx} cy={cy} rx={260} ry={250} fill={color} opacity={0.12} />
    </g>
  );
};

/** Scene 4 — Transisi lingkaran dari wajah ke ilustrasi otak. */
export const BrainScene: React.FC = () => {
  const f = useCurrentFrame();
  const reveal = ease(f, 0, 38, 0, 1, INOUT);
  const cortex = 0.55 + 0.35 * Math.sin(f / 10);
  const zoom = 1.18 - 0.1 * ease(f, 0, 240, 0, 1, INOUT);
  const lab = (d: number) => ease(f, d, d + 14);
  return (
    <Stage bg={C.navy2}>
      <SceneSvg>
        <defs>
          <clipPath id="irisClip">
            <circle cx={360} cy={640} r={reveal * 1000} />
          </clipPath>
          <linearGradient id="bgBrain" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#141a30" />
            <stop offset="1" stopColor="#262449" />
          </linearGradient>
        </defs>
        <g clipPath="url(#irisClip)">
          <rect x={-300} y={-300} width={W + 600} height={H + 600} fill="url(#bgBrain)" />
          <CameraRig x={360} y={660} zoom={zoom}>
            <Layer depth={0.4}>
              <Halo cx={360} cy={660} />
            </Layer>
            <Layer depth={1}>
              <Brain x={360} y={660} scale={1.5} cortex={cortex} stem={0.3} />
            </Layer>
          </CameraRig>
          {/* garis keterangan */}
          <g stroke={C.beige} strokeWidth={2} opacity={0.7} fill="none">
            <path d="M440 590 L560 540 L690 540" strokeDasharray="300" strokeDashoffset={300 * (1 - lab(70))} />
            <path d="M385 812 L470 880 L690 880" strokeDasharray="330" strokeDashoffset={330 * (1 - lab(110))} />
          </g>
        </g>
      </SceneSvg>
      <Overlay>
        <Watermark />
        <RevealText text="Ini bukan \n hantu." x={40} y={226} size={96} delay={22} />
        <Kicker text="KORTEKS" x={470} y={518} w={220} align="right" delay={72} size={16} />
        <Kicker text="BATANG OTAK" x={450} y={858} w={240} align="right" delay={112} size={16} />
        <RevealText
          text="Ini kerja otakmu."
          x={260}
          y={1040}
          w={420}
          align="right"
          size={42}
          font="serif"
          italic
          weight={400}
          color={C.beige}
          delay={90}
        />
      </Overlay>
    </Stage>
  );
};
