// Sistem desain tunggal. Semua scene mengambil warna & font dari sini.
// Palet diambil dari video referensi (navy gelap, ungu redup, abu, aksen beige).

export const W = 720; // koordinat desain (sama dengan video referensi 720x1280)
export const H = 1280;
export const OUT_W = 1080; // ukuran render akhir (di-scale 1.5x dari koordinat desain)
export const OUT_H = 1920;
export const FPS = 30;

export const C = {
  bgDeep: '#0f1320',
  navy: '#151a2b',
  navy2: '#1b2240',
  navyBlue: '#26335c', // kaca jendela / panel biru
  purple: '#3a3354',
  purpleMid: '#4b4568',
  purpleLight: '#6a6489',
  blanket: '#4d4868',
  grey: '#8a8fa3',
  greyDark: '#444056',
  greyShirt: '#7d8196',
  door: '#2c2838',
  doorDark: '#241f2e',
  beige: '#d8b98a', // aksen hangat
  beigeSoft: '#f0e2c8',
  skin: '#d9a98a',
  hair: '#1b1d2e',
  cream: '#efe8dc',
  white: '#ffffff',
  fear: '#6c3f6a', // ungu-magenta redup, hanya untuk adegan takut
  chat: '#34507f',
  chatDark: '#222a43',
  card: 'rgba(22,26,42,0.82)',
} as const;

export const FONT_SANS = "'Inter', 'Helvetica Neue', Arial, sans-serif";
export const FONT_SERIF = "'Caladea', 'Georgia', 'Times New Roman', serif";

export const HANDLE = '@namakamu'; // ganti dengan akun kamu
