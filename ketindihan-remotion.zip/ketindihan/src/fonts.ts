import {continueRender, delayRender, staticFile} from 'remotion';

// Semua font dimuat dari public/fonts (lokal), tidak ada request ke internet.
const FACES: [string, string, string, string][] = [
  ['Inter', 'Inter-Regular.otf', '400', 'normal'],
  ['Inter', 'Inter-Medium.otf', '500', 'normal'],
  ['Inter', 'Inter-SemiBold.otf', '600', 'normal'],
  ['Caladea', 'Caladea-Regular.ttf', '400', 'normal'],
  ['Caladea', 'Caladea-Bold.ttf', '700', 'normal'],
  ['Caladea', 'Caladea-Italic.ttf', '400', 'italic'],
];

export const loadFonts = () => {
  const handle = delayRender('memuat font lokal');
  Promise.all(
    FACES.map(([family, file, weight, style]) =>
      new FontFace(family, `url(${staticFile('fonts/' + file)})`, {weight, style})
        .load()
        .then((f) => {
          document.fonts.add(f);
        }),
    ),
  )
    .catch((e) => console.warn('Font gagal dimuat, pakai fallback:', e))
    .finally(() => continueRender(handle));
};
