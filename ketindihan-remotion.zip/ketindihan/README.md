# Video "Kenapa Kita Bisa Ketindihan?" (Remotion)

Animasi 2D flat vector (SVG + React). 1080×1920, 30 fps, ±65 detik. Tidak butuh API/cloud berbayar; semua aset (font, audio) ada di `public/`.

## Jalankan di GitHub Codespaces
```bash
npm install
npm run dev          # Remotion Studio (port 3000) untuk preview
npm run render:fast  # preview 540x960 cepat -> out/preview.mp4
npm run render       # final 1080x1920 -> out/ketindihan.mp4
```
Jika `npm install` mengeluh versi Remotion, jalankan `npx remotion upgrade`.
Jika render kehabisan memori, turunkan `Config.setConcurrency` di `remotion.config.ts` jadi 1.
Unduh hasil dari panel Explorer (klik kanan `out/ketindihan.mp4` → Download).

## Yang perlu kamu sesuaikan
- `src/theme.ts` → `HANDLE` (akun watermark).
- `src/timing.ts` → batas waktu tiap scene (disesuaikan dengan narasi).
- Teks di `src/scenes/*.tsx` (kalimat on-screen).
- Ganti narasi: timpa `public/audio/narasi.mp3`, lalu perbarui `AUDIO_SECONDS` dan `SCENES`.

## Struktur
- `src/svg/` — sistem SVG reusable: `Room`, `Character`, `Anatomy` (otak, tubuh, sosok bayangan).
- `src/Camera.tsx` — kamera 2D + layer parallax. `src/ui/UI.tsx` — tipografi, bubble chat, kartu.
- `src/scenes/` — 9 scene. `src/Root.tsx` — menyusun Sequence + audio.
- `docs/STYLE_GUIDE.md` — analisis referensi, style guide, storyboard.
