# Style Guide & Storyboard — "Kenapa Kita Bisa Ketindihan?"

## 1. Analisis video referensi (30,8 dtk, 720×1280, 30 fps)
- **Ilustrasi**: 2D flat vector, karakter tanpa fitur wajah detail, bentuk geometris (elips kepala, trapesium torso), bayangan lembut, gradien halus.
- **Palet**: navy gelap (#141825), ungu redup (selimut/kasur #4d4868), abu desaturasi (baju, kalender), aksen beige hangat (label, lampu, teks italic).
- **Lingkungan**: kamar minimalis satu sudut: jendela + bulan, kalender, pintu, jaket menggantung, nakas + lampu, ranjang. Lantai gelap di bawah ±y=990 jadi ruang kosong untuk UI.
- **Komposisi**: angka/teks besar di atas (y≈250–340), ilustrasi di tengah, banyak negative space di bawah. Split-screen vertikal 50/50 dengan header berspasi lebar ("ADIK" | "KAKAK").
- **Elemen UI**: kartu notifikasi bank (ikon bulat + label caps + nilai), gelembung chat biru dengan efek mengetik, garis lengkung (arc) antar karakter, ponsel dengan halo konsentris di akhir.
- **Motion**: gerak karakter halus, kamera push/zoom pelan, debu melayang, teks masuk dengan blur+naik, keluar dengan fade, transisi dengan crossfade/wipe.
- **Tipografi**: Inter untuk angka & kata kunci; serif editorial (reguler + *italic beige*) untuk kalimat penutup.
- **Alur**: hook (angka besar) → ritme "kejadian → angka berubah" → perubahan komposisi → klimaks → closing kalimat serif.

## 2. Design tokens (src/theme.ts)
navy #151a2b · navy2 #1b2240 · ungu #3a3354 / #4d4868 · abu #7d8196 · beige #d8b98a · krem #efe8dc · kulit #d9a98a · rambut #1b1d2e.
Font lokal: Inter (sans), Caladea (serif editorial, kompatibel Cambria). Disimpan di `public/fonts`.

## 3. Karakter (src/svg/Character.tsx)
Satu rig untuk semua scene: torso berotasi dari pinggul (berbaring → duduk), kepala dengan rambut + sanggul konsisten, baju abu, tangan di atas selimut.
Parameter: `lie` (0 berbaring ↔ 1 duduk), `eye` (tidur ↔ terbuka), `fear`, `calm`, `lookX/lookY`, `strain` (getar), `twitch` (jari), `breath`.
Pose yang tercakup: tidur, terbangun, mata terbuka, takut, berusaha bergerak, melihat ke pintu, kembali tenang.

## 4. Storyboard (waktu mengikuti jeda napas narasi.mp3; ubah di src/timing.ts)
| # | Waktu | Scene | Komposisi | Motion |
|---|---|---|---|---|
| 1 | 0:00–4:09 | Hook | Kamar malam, teks besar "Ketindihan" di atas | Kamera dolly-in, napas, debu, parallax |
| 2 | 4:09–9:07 | Terbangun, tak bisa bergerak | Close-up wajah, chip jam 03:12, "Sadar." serif italic | Mata terbuka, tubuh bergetar, jari berkedut |
| 3 | 9:07–18:03 | Takut & halusinasi | Pan ke pintu → **split-screen** wajah ǀ sosok bayangan, bubble chat sensasi | Pintu terbuka, panah tekanan dada, tint ungu |
| 4 | 18:03–26:15 | Otak | Wipe lingkaran → otak besar + halo, callout garis | Otak melayang, korteks berdenyut |
| 5 | 26:15–36:29 | Tidur REM | **Split-screen** OTAK ǀ TUBUH, "REM" besar, hipnogram | EEG bergelombang, mata bergerak, grafik tergambar |
| 6 | 36:29–47:09 | Atonia REM | Otak di atas, tubuh di bawah, gerbang terkunci | Sinyal berhenti di gerbang, node otot padam |
| 7 | 47:09–56:23 | Pemicu | "±8%" besar, otak + amigdala, 3 kartu notifikasi | Amigdala berdenyut, kartu muncul bergantian |
| 8 | 56:23–60:11 | Bisa bergerak | Kamar lagi, kamera mundur | Jari → bangun duduk (spring), lampu menyala |
| 9 | 60:11–65:23 | Closing | Bulan sabit + serif besar di tengah halo | Kata muncul bergantian, fade out |

## 5. Catatan konten
Angka "±8%" berasal dari meta-analisis prevalensi seumur hidup (sekitar 7,6% populasi umum). Verifikasi dan sesuaikan dengan narasimu.
